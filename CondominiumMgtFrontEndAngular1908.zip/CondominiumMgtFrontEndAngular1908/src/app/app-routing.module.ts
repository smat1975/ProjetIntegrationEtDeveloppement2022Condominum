import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
/*import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatSliderModule } from '@angular/material/slider';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { ToastrModule } from './angular-toastr';*/
import { CommonModule } from '@angular/common';
// import { ToastrModule } from 'ngx-toastr';
// import { JwtModule } from '@auth0/angular-jwt';
// import { AuthentificationService } from 'src/app/services/authentification.service';
// import { AuthgardService } from './services/authgardAncien.service';
import { SharedService } from './services/shared.service';

import { AppComponent } from './app.component';

//import { CallApiComponent } from '../call-api/call-api.component';

import { HomeComponent } from './home/home.component';

// import { LoginComponent } from './login/login.component';ng serve
// import { LogoutComponent } from './logout/logout.component';

/*import { MessagesComponent } from './messages/messages.component';*/
//import { ListMessagesComponent } from './messages/list-messages/list-messages.component';
//import { MessagesListeComponent } from './messages/messages-liste/messages-liste.component';
/*import { MessagesFormComponent } from './messages/messages-form/messages-form.component';*/
//import { MessagesAjouterComponent } from './messages/messages-ajouter/messages-ajouter.component';
//import { MessagesModifierComponent } from './messages/messages-modifier/messages-modifier.component';
//import { MessagesSupprimerComponent } from './messages/messages-supprimer/messages-supprimer.component';
//import { MessagesDetailsComponent } from './messages/messages-details/messages-details.component';
// import { MessagesConfirmationComponent } from './messages/messages-confirmation/messages-confirmation.component';
// import { UtilisateursComponent } from 'src/app/utilisateurs/utilisateurs.component';
/*import { UtilisateurAjouterComponent } from '../utilisateur/utilisateur-ajouter/utilisateur-ajouter.component';
import { GestionComponent } from '../gestion/gestion.component';
import { GestionValvesComponent } from '../gestion/gestion-valves/gestion-valves.component';
import { GestionUserCoproprietairesComponent } from '../gestion/gestion-user-coproprietaires/gestion-user-coproprietaires.component';
import { GestionLotsComponent } from '../gestion/gestion-lots/gestion-lots.component';
import { GestionOccupationComponent } from '../gestion/gestion-occupation/gestion-occupation.component';
import { GestionRdvComponent } from '../gestion/gestion-rdv/gestion-rdv.component';
import { GestionSujetsAcpComponent } from '../gestion/gestion-sujets-acp/gestion-sujets-acp.component';
import { GestionPhotosComponent } from '../gestion/gestion-photos/gestion-photos.component';*/
import { LoadingComponent } from './loading/loading.component';
// import { LoginComponent } from '../login/login.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { MessagesModule } from './messages/messages.module';
//import { ListMessagesComponent } from './messages/list-messages/list-messages.component';
/*import { TestSelectComponent } from './test-select/test-select.component';
import { AdminComponent } from '../admin/admin.component';
import { AdminMessagesComponent } from '../admin/admin-messages/admin-messages.component';
import { AdminValvesComponent } from '../admin/admin-valves/admin-valves.component';
import { UserComponent } from '../user/user.component';
import { DestinationsComponent } from '../destinations/destinations.component';
import { DestinationsAjouterComponent } from '../destinations/destinations-ajouter/destinations-ajouter.component';
import { GestionCoproprieteComponent } from '../gestion/gestion-coproriete/gestion-copropriete.component';
import { GestionCoproprieteAjouterComponent } from '../gestion/gestion-coproriete/gestion-copropriete-ajouter/gestion-copropriete-ajouter.component';
*/


const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch : 'full' },
    { path: 'home', component: HomeComponent },
    //{ path: 'list-messages', component: ListMessagesComponent },
    /*{ path: 'messages-liste', component: MessagesListeComponent },
    { path: 'messages-details', component: MessagesDetailsComponent },*/
    //{ path: 'messages-ajouter', component: MessagesAjouterComponent },
    //{ path: 'messages-modifier', component: MessagesModifierComponent },
    //{ path: 'list-messages', redirectTo: 'messages/list-messages' },
    // { path: 'login', component: LoginComponent },
    // { path: 'logout', component: LogoutComponent },
    // { path: 'infos-acp', component: InfosAcpComponent },
    // { path: 'conseil-acp', component: ConseilAcpComponent },
    // { path: 'list-messages', component: MessagesComponent },
    // { path: 'list-messages', component: ListMessagesComponent },
    // { path: 'messages/Messages', redirectTo: 'messages' },
    // { path: 'messages-ajouter', component: MessagesAjouterComponent },
    // { path: 'messages-details/:id', component: MessagesDetailsComponent },
    // { path: 'messages-modifier/:id', component: MessagesModifierComponent },
    // { path: 'messages-modifier/:id/MessageConfirmation', component: MessagesConfirmationComponent },
    // { path: 'messages-supprimer/:id/MessageConfirmation', component: MessagesConfirmationComponent },
    // { path: 'messages-modifier/:id/MessageConfirmation', redirectTo: 'messages-confirmation' },
    // { path: 'messages-supprimer/:id/MessageConfirmation', redirectTo: 'messages-confirmation' },
    // { path: 'messages-supprimer/:id', component: MessagesSupprimerComponent },
    // { path: 'messages-confirmation/', component: MessagesConfirmationComponent },
    // { path: 'destinations/', component: DestinationsComponent },
    // { path: 'destinations/Messages', redirectTo: 'messages' },
    // { path: 'destinations-ajouter/:id', component: DestinationsAjouterComponent },
    // { path: 'destinations-ajouter/:id/MessagesAjouter/:id', redirectTo: 'messages-ajouter' },
    // { path: 'messages-details/:id/Messages/', redirectTo: 'messages' },
    // { path: 'messages-details/:id/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // { path: 'messages-details/:id/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'messages/GestionValves/', redirectTo: 'gestion-valves' },
    // { path: 'messages/MessagesAjouter/', redirectTo: 'messages-ajouter' },
    // { path: 'messages/MessagesDetails/:id', redirectTo: 'messages-details' },
    // { path: 'messages/MessagesDetails/:id/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // { path: 'messages/MessagesDetails/:id/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'messages/MessagesDetails/:id/Messages', redirectTo: 'messages' },
    // { path: 'messages/MessagesModifier/:id/MessagesConfirmation', redirectTo: 'messages-confirmation' },
    // { path: 'messages/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // { path: 'messages/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'messages/MessagesSupprimer/MessagesConfirmation/', redirectTo: 'messages-confirmation' },
    // { path: 'Messages-modifier/:id/MessagesConfirmation/', redirectTo: 'messages-confirmation' },
    // { path: 'messages/MessagesAjouter/DestinationsAjouter/', redirectTo: 'destinations-ajouter' },
    // { path: 'messages/MessagesAjouter/MessagesConfirmation/', redirectTo: 'messages-confirmation' },
    // { path: 'messages-ajouter/DestinationsAjouter/', redirectTo: 'destinations-ajouter' },
    // { path: 'messages/GestionValves', redirectTo: 'gestion-valves' },
    // { path: 'utilisateur', component: UtilisateurComponent },
    // { path: 'utilisateur/UtilisateurAjouter', component: UtilisateurAjouterComponent },
    // { path: 'gestion', /*canActivate: [AuthGuard],*/component: GestionComponent },
    // { path: 'gestion/Messages', component: MessagesComponent },
    // { path: 'gestion/Messages/Messages', redirectTo: 'messages' },
    // { path: 'gestion/Messages/MessagesAjouter', redirectTo: 'messages-ajouter' },
    // { path: 'gestion/Messages/MessagesDetails/:id', redirectTo: 'messages-details' },
    // { path: 'gestion/Messages/MessagesDetails/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'gestion/Messages/MessagesDetails/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // { path: 'gestion/Messages/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // { path: 'gestion/Messages/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'gestion/Messages/GestionValves', redirectTo: 'gestion-valves' },
    // { path: 'gestion/Messages/gestion', redirectTo: 'gestion' },
    // { path: 'gestion/GestionValves', redirectTo: 'gestion-valves' },
    // { path: 'gestion/GestionValves/Messages', redirectTo: 'messages' },
    // { path: 'gestion/GestionValves/MessagesAjouter', redirectTo: 'messages-ajouter' },
    // { path: 'gestion/GestionValves/MessagesDetails/:id', redirectTo: 'messages-details' },
    // { path: 'gestion/GestionValves/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // { path: 'gestion/GestionValves/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'gestion/GestionValves/gestion', redirectTo: 'gestion' },
    // //{ path: 'gestion/GestionValves/Messages', component: MessagesComponent },
    // { path: 'gestion/Utilisateur', component: UtilisateurComponent },
    // { path: 'gestion/Utilisateur/UtilisateurAjouter', redirectTo: 'utilisateur-ajouter' },
    // { path: 'gestion/Utilisateur/GestionValves', redirectTo: 'gestion-valves' },
    // { path: 'gestion/Utilisateur/Messages', redirectTo: 'messages' },
    // { path: 'gestion-valves', component: GestionValvesComponent },
    // { path: 'gestion-valves/GestionValves', redirectTo: 'gestion-valves' },
    // { path: 'gestion-valves/MessagesAjouter', redirectTo: 'messages-ajouter' },
    // { path: 'gestion-valves/MessagesDetails/:id', redirectTo: 'messages-details' },
    // //{ path: 'gestion-valves/MessagesModifier/:id', redirectTo: 'messages-modifier' },
    // //{ path: 'gestion-valves/MessagesSupprimer/:id', redirectTo: 'messages-supprimer' },
    // { path: 'gestion-valves/Messages', redirectTo: 'messages' },
    // { path: 'gestion-coproprietaires', component: GestionUserCoproprietairesComponent },
    // { path: 'gestion-copropriete/', component: GestionCoproprieteComponent },
    // { path: 'gestion-copropriete/', redirectTo: 'gestion-copropriete' },
    // { path: 'gestion-copropriete-ajouter/', redirectTo: 'gestion-copropriete-ajouter' },
    // { path: 'gestion-copropriete-ajouter/', component: GestionCoproprieteAjouterComponent },
    // { path: 'gestion-copropriete/GestionCoproprieteAjouter', redirectTo: 'gestion-copropriete-ajouter' },
    // { path: 'gestion/GestionCopropriete/GestionCoproprieteAjouter', redirectTo: 'gestion-copropriete-ajouter' },
    // { path: 'gestion/GestionCopropriete/GestionCoproprieteAjouter/GesstionCopropriete', redirectTo: 'gestion-copropriete' },
    // { path: 'gestion-Lots', component: GestionLotsComponent },
    // { path: 'gestion-occupation', component: GestionOccupationComponent },
    // { path: 'gestion-rdv', component: GestionRdvComponent },
    // { path: 'gestion-sujetsacp', component: GestionSujetsAcpComponent },
    // { path: 'gestion-photos', component: GestionPhotosComponent },
    // { path: 'admin', /*canActivate: [AuthGuard],*/component: AdminComponent },
    // { path: 'admin-valves', component: AdminValvesComponent },
    // { path: 'admin-messages', component: AdminMessagesComponent },
    // { path: 'admin/AdminMessages', /*canActivate: [AuthGuard],*/component: AdminMessagesComponent },
    // { path: 'admin/Utilisateur', /*canActivate: [AuthGuard],*/component: UtilisateurComponent },
    // { path: 'admin/AdminValves', /*canActivate: [AuthGuard], redirectTo: 'admin'*/ component: AdminValvesComponent },
    
    //{ path: 'user', /*canActivate: [AuthGuard],*/ component: UserComponent },
    //{ path: 'user/:id', /*canActivate: [AuthGuard],*/ component: UserComponent },
    
    { path: 'loading', component: LoadingComponent },
    // { path: 'call-api', canActivate: [AuthgardService], component: CallApiComponent },
    
    { path: 'not-found', component: NotFoundComponent },
    { path: '**', redirectTo: 'not-found' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
