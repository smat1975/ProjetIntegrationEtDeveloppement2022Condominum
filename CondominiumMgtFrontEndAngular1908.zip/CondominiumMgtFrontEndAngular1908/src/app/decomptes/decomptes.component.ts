import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-decomptes',
  templateUrl: './decomptes.component.html',
  styleUrls: ['./decomptes.component.css']
})
export class DecomptesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
