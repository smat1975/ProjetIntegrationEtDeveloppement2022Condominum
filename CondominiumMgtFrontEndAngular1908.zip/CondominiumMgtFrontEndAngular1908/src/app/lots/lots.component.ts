import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lots',
  templateUrl: './lots.component.html',
  styleUrls: ['./lots.component.css']
})
export class LotsComponent implements OnInit {

  constructor() { }

 

  ngOnInit(): void {
  }

}
