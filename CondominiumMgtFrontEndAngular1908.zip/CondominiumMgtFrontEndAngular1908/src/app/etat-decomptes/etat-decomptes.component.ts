import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etat-decomptes',
  templateUrl: './etat-decomptes.component.html',
  styleUrls: ['./etat-decomptes.component.css']
})
export class EtatDecomptesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
