import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EtatDecomptesComponent } from './etat-decomptes.component';

describe('EtatDecomptesComponent', () => {
  let component: EtatDecomptesComponent;
  let fixture: ComponentFixture<EtatDecomptesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EtatDecomptesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EtatDecomptesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
