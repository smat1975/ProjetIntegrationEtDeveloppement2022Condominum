﻿// <reference path="../../node_modules/@types/jasmine/index.d.ts" />
import { TestBed, async, ComponentFixture, ComponentFixtureAutoDetect } from '@angular/core/testing';
import { BrowserModule, By } from "@angular/platform-browser";
import { UtilisateursComponent } from 'src/app/utilisateurs/utilisateurs.component';

let component: UtilisateursComponent;
let fixture: ComponentFixture<UtilisateursComponent>;

describe('Utilisateurs component', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ UtilisateursComponent ],
            imports: [ BrowserModule ],
            providers: [
                { provide: ComponentFixtureAutoDetect, useValue: true }
            ]
        });
        fixture = TestBed.createComponent(UtilisateursComponent);
        component = fixture.componentInstance;
    }));

    it('should do something', async(() => {
        expect(true).toEqual(true);
    }));
});