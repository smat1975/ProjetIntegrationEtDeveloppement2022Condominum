import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Utilisateurs } from 'src/app/shared/utilisateurs';
import { SharedService } from 'src/app/services/shared.service';
// import { MatSelectModule } from '@angular/material/select';


@Component({
  selector: 'app-utilisateurs-ajouter',
  templateUrl: './utilisateurs-ajouter.component.html',
  styleUrls: ['./utilisateurs-ajouter.component.css']
})
export class UtilisateursAjouterComponent {
  utilisateur!: Utilisateurs;
  utilisateurForm = this.fb.group({
    nomUtilisateur: [null, Validators.required],
    prenomsUtilisateur: [null, Validators.required],
    emailUtilisateur: [null, Validators.required],
    dateNaissanceUtilisateur: [null, Validators.required],
    idTypeUtilisateur: [null, Validators.required],
    remarque: null,
    dateDebut: null,
    dateFin: null
  });

  constructor(private fb: FormBuilder, private service: SharedService) { }

  onSubmit(): void {
    this.utilisateur = <Utilisateurs>this.utilisateurForm.value;
    this.service.creerUtilisateur(this.utilisateur);

  }
}
