﻿import { Component } from '@angular/core';

@Component({
    selector: 'app-utilisateurs',
    templateUrl: './utilisateurs.component.html',
    styleUrls: ['./utilisateurs.component.css']
})
/** Utilisateur component*/
export class UtilisateursComponent {
    /** Utilisateur ctor */
    constructor() {

    }
}