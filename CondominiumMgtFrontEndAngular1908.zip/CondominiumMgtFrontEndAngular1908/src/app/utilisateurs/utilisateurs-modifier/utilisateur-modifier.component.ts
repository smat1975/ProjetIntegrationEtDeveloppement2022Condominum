import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Utilisateur } from '../../app/shared/utilisateur';
import { SharedService } from '../../Services/shared.service';
import { MatSelectModule } from '@angular/material/select';


@Component({
  selector: 'app-utilisateur-ajouter',
  templateUrl: './utilisateur-ajouter.component.html',
  styleUrls: ['./utilisateur-ajouter.component.css']
})
export class UtilisateurModifierComponent {
  utilisateur!: Utilisateur;
  utilisateurForm = this.fb.group({
    idAcp: [null, Validators.required],
    idUtilisateur: [null, Validators.required],
    titreMessage: [null, Validators.required],
    contenuMessage: [null, Validators.required],
    idTypeMessage: [null, Validators.required],
    idPriorite: [null, Validators.required],
    idPiece: null
  });

  idAcps = [
    { name: 'Résidence des Lilas', abbreviation: 'RL' }
  ];

  constructor(private fb: FormBuilder, private service: SharedService) { }

  onSubmit(): void {
    this.utilisateur = <Utilisateur>this.utilisateurForm.value;
    this.service.creerUtilisateur(this.utilisateur);

  }
}
