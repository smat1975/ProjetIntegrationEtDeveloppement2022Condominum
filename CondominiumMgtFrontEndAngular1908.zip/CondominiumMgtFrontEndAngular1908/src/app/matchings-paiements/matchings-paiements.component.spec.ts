import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MatchingsPaiementsComponent } from './matchings-paiements.component';

describe('MatchingsPaiementsComponent', () => {
  let component: MatchingsPaiementsComponent;
  let fixture: ComponentFixture<MatchingsPaiementsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MatchingsPaiementsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MatchingsPaiementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
