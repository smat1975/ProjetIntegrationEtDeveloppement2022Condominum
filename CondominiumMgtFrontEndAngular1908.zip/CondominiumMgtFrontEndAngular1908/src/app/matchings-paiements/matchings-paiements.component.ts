import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matchings-paiements',
  templateUrl: './matchings-paiements.component.html',
  styleUrls: ['./matchings-paiements.component.css']
})
export class MatchingsPaiementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
