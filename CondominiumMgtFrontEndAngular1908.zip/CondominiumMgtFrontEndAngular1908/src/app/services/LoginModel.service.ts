/*import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators'

@Injectable()
export class LoginModel {
  email: string;
  password: string;
}

signIn(email: string, password: string) {
  var cred = new LoginModel();
  cred.email = email;
  cred.password = password;
  this.http.post(this.util.apiUrl + '/apibackend/authenticate/login', cred)
    .subscribe(
      response => {
        const token = (<any>response).token;
        localStorage.setItem("jwt", token);
      },
      err => {
        console.log('signIn error : ' + JSON.stringify(err));
      }
    )
}

signOut() {
  localStorage.removeItem("jwt");
}
*/
