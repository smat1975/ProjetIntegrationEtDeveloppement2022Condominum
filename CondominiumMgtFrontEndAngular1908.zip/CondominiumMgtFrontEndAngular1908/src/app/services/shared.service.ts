import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { retry, catchError, map } from 'rxjs/operators'


// -- Messaging -- //

import { Coproprietaires } from 'src/app/shared/coproprietaires'
import { Utilisateurs } from 'src/app/shared/utilisateurs'
import { Messages } from 'src/app/shared/messages'
import { MessagesComplexe } from 'src/app/shared/messagescomplexe'
import { MessagesComplet } from 'src/app/shared/messagescomplet'
import { Destinations } from 'src/app/shared/destinations'
import { Photos } from 'src/app/shared/photos'
import { Annexes } from 'src/app/shared/annexes'

// -- Autres Modèles -- //

import { Civilites } from 'src/app/shared/civilites'
import { CodesPcmn } from 'src/app/shared/codes-pcmn'
import { ComptesBque } from 'src/app/shared/comptes-bque'
import { Coproprietes } from 'src/app/shared/coproprietes';
import { Decomptes } from 'src/app/shared/decomptes';
import { DocumentsFournisseurs } from 'src/app/shared/documents-fournisseurs';
import { Fournisseurs } from 'src/app/shared/fournisseurs';
import { Groupements } from 'src/app/shared/groupements'
import { Groupes } from 'src/app/shared/groupes'
import { LignesDecomptes } from 'src/app/shared/lignes-decomptes'
import { LignesDocumentsFournisseurs } from 'src/app/shared/lignes-documents-fournisseurs';
import { Localisations } from 'src/app/shared/localisations';
import { Lots } from 'src/app/shared/lots';
import { MatchingsPaiements } from 'src/app/shared/matchings-paiements';
import { Paiements } from 'src/app/shared/paiements';
import { Periodes } from 'src/app/shared/periodes';
import { Quotites } from 'src/app/shared/quotites';
import { RaisonsCloture } from 'src/app/shared/raisonscloture'
import { Sexes } from 'src/app/shared/sexes'
import { TypesDocumentFournisseur } from 'src/app/shared/types-document-fournisseur'
import { TypesLot } from 'src/app/shared/types-lot';
import { TypesMessage } from 'src/app/shared/types-message';
import { TypesTva } from 'src/app/shared/types-tva';

// -- Additionnels -- //

import { MessagesPublicsToShow } from 'src/app/shared/messagespublicstoshow'
import { MessagesToShow } from 'src/app/shared/messagestoshow';
import { MessagesUtilisateurToShow } from 'src/app/shared/messagesutilisateurtoshow'
import { MessagesToCreate } from 'src/app/shared/messagestocreate';
import { AnnexeToCreate } from 'src/app/shared/annexetocreate'
import { DestinationToCreate} from 'src/app/shared/destinationtocreate';
//import { tokenGetter } from '../app-routing.module';

// ---- //

@Injectable({
  providedIn: 'root'
})
export class SharedService {

   APIUrl = "https://localhost:44392/backendapi";
   /*PhotoUrl = "https://localhost:44302/apibackend/photos";*/

   /*A remplacer par l'usage d'un callAPI vers un espace de stockage en cloud!!!!*/

   constructor(private http: HttpClient/*, private nouveauMessage: Messages*/) {

  }

 typesMessage: TypesMessage[] = [
   { idTypeMessage: 1, denomination: 'Avertissement', description: 'Avertissement' },
   { idTypeMessage: 2, denomination: 'Information', description: 'Information' },
   { idTypeMessage: 3, denomination: 'Appel', description: 'Appel' },
   { idTypeMessage: 4, denomination: 'Rappel', description: 'Rappel' },
   { idTypeMessage: 5, denomination: 'Message publique', description: 'Message publique' },
 ];

 // public photo: Photos = new Photos();


 public listMessages: Messages[] = [];
 public listAnnexes: Annexes[] = [];
 public listDestinations: Destinations[] = [];
 public listPhotos: Photos[] = [];

 public listCoproprietaires: Coproprietaires[] = [];
 public listCoproprietes: Coproprietes[] = [];
 public listLots: Lots[] = [];

 public listComptesBque: ComptesBque[] = [];
 public listDecomptes: Decomptes[] = [];
 public listDocumentsFournisseurs: DocumentsFournisseurs[] = [];
 public listFournisseurs: Fournisseurs[] = [];
 public listGroupements: Groupements[] = [];
 public listGroupes: Groupes[] = [];
 public listLignesDecomptes: LignesDecomptes[] = [];
 public listLignesDocumentsFournisseurs: LignesDocumentsFournisseurs[] = [];
 public listMatchingsPaiements: MatchingsPaiements[] = [];
 public listPaiements: Paiements[] = [];

 public listCodesPcmn: CodesPcmn[] = [];
 public listLocalisations: Localisations[] = [];
 public listPeriodes: Periodes[] = [];
 public listQuotites: Quotites [] = [];

 public listCivilites: Civilites[] = [];
 public listRaisonsCloture: RaisonsCloture [] = [];
 public listSexes: Sexes [] = [];
 public listTypesDocumentsFournisseur: TypesDocumentFournisseur[] = [];
 public listTypesLots: Lots[] = [];
 public listTypesMessage: TypesMessage[] = [];
 public listTypesTva: TypesTva[] = [];


 loadCodesPcmn(): Observable<void>{
   return this.http.get<[]>('/backendapi/codespcmn/listallcodespcmn')
   .pipe(map(data => { this.listCodesPcmn = data;
     return;    
   }));
 }

 loadLocalisations(): Observable<void>{
   return this.http.get<[]>('/backendapi/localisations/listalllocalisations')
   .pipe(map(data => { this.listTypesLots = data;
     return;    
   }));
 }

 loadPeriodes(): Observable<void>{
   return this.http.get<[]>('/backendapi/periodes/listallperiodes')
   .pipe(map(data => { this.listPeriodes = data;
     return;    
   }));
 }

 loadQuotites(): Observable<void>{
   return this.http.get<[]>('/backendapi/quotites/listallquotites')
   .pipe(map(data => { this.listQuotites = data;
     return;    
   }));
 }



loadCivilites(): Observable<void>{
   return this.http.get<[]>('/backendapi/civilites/listallcivilites')
   .pipe(map(data => { this.listCivilites = data;
     return;    
   }));
}

loadRaisonsCloture(): Observable<void>{
 return this.http.get<[]>('/backendapi/raisonscloture/listallraisonscloture')
 .pipe(map(data => { this.listRaisonsCloture = data;
   return;    
 }));
}

loadSexes(): Observable<void>{
 return this.http.get<[]>('/backendapi/sexes/listallsexes')
 .pipe(map(data => { this.listSexes = data;
   return;    
 }));
}

loadTypesDocumentsFournisseur(): Observable<void>{
 return this.http.get<[]>('/backendapi/typesdocumentsfournisseur/listalltypesdocumentsfournisseur')
 .pipe(map(data => { this.listTypesMessage = data;
   return;    
 }));
}

loadTypesLots(): Observable<void>{
 return this.http.get<[]>('/backendapi/typeslots/listalltypeslots')
 .pipe(map(data => { this.listTypesLots = data;
   return;    
 }));
}

 loadTypesMessage(): Observable<void>{
     return this.http.get<[]>('/backendapi/typesmessage/listalltypesmessage')
     .pipe(map(data => { this.listTypesMessage = data;
       return;    
     }));
 }

 loadTypesTva(): Observable<void>{
   return this.http.get<[]>('/backendapi/typestva/listalltypestva')
   .pipe(map(data => { this.listTypesTva = data;
     return;    
   }));
 }



  // loadLots(){
  //     return this.http.get<[]>: Observable<void>('/backendapi/lots/listalllots')
  //     .pipe(map(data => { this.lots = data;
  //       return;    
  //     }));
  // }

  /*====================================================*/
  /* PAGE DES SERVICES PARTAGES PAR TOTUE L'APPLICATION */
  /*====================================================*/


  /*=============================================================*/
  /* Méthodes CRUD pour consommer les APIs Restful du BackEndAPI */
  /*=============================================================*/

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  
  //Page accueil//

  // HttpClient API get() method => Get/Fetch ListeMessagesPublics
  getListeAllMessagesPublicsToShow(): Observable<MessagesPublicsToShow> {
    return this.http.get<MessagesPublicsToShow>(this.APIUrl + '/VuesHandling/ListeMessagesPublicsToShow')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  getListeAllMessagesToShow(): Observable<MessagesToShow> {
    return this.http.get<MessagesToShow>(this.APIUrl + '/VuesHandling/listemessagestoshow/')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // getAllInfosAcp(): Observable<InfosAcp> {
  //   return this.http.get<InfosAcp>(this.APIUrl + '/InfosAcps/ListeAllInfosAcp')
  //     .pipe(
  //       retry(1),
  //       catchError(this.handleError)
  //     )
  // }

  // getAllConseilAcp(): Observable<ConseilAcp> {
  //   return this.http.get<ConseilAcp>(this.APIUrl + '/ConseilAcps/ListeAllConseilAcp')
  //     .pipe(
  //       retry(1),
  //       catchError(this.handleError)
  //     )
  // }

  //***********/
  // Messages //
  //**********//

    // HttpClient API get() method => Get/Fetch ListeAllMessages
    getListeAllMessages(): Observable<Messages> {
      return this.http.get<Messages>(this.APIUrl + '/Messages/listeallmessages/')
        .pipe(
          retry(1),
          catchError(this.handleError)
        )
    }

        // HttpClient API get() method => Get/Fetch ListeAllMessages
        getListeAllMessagesComplexe(): Observable<MessagesComplexe> {
          return this.http.get<MessagesComplexe>(this.APIUrl + '/messages/listallmessagescomplexe/')
            .pipe(
              retry(1),
              catchError(this.handleError)
            )
        }

        // HttpClient API get() method => Get/Fetch ListeAllMessages complet
        getListeAllMessagesComplet(): Observable<MessagesComplet> {
          return this.http.get<MessagesComplet>(this.APIUrl + '/messages/listallmessagescomplet/')
                    .pipe(
                      retry(1),
                      catchError(this.handleError)
                    )
                }

  // HttpClient API get() method => Get/Fetch ListeMessagesPublics
  getListeAllMessagesPublics(): Observable<Messages> {
    return this.http.get<Messages>(this.APIUrl + '/Messages/listeallmessagespublics/')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch ListeMessagesNonPublics
  getListeAllMessagesNonPublics(): Observable<Messages> {
    return this.http.get<Messages>(this.APIUrl + '/Messages/ListeAllMessagesNonPublics')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch ListeAllMessagesUtilisateur
  getListeAllMessagesUtilisateur(id: number): Observable<Messages> {
    return this.http.get<Messages>(this.APIUrl + '/Messages/ListeAllMessagesUtilisateur' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch ListeAllMessagesAdmin
  getListeAllMessagesAdmin(): Observable<Messages> {
    return this.http.get<Messages>(this.APIUrl + '/Messages/ListeAllMessagesAdmin')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch Message déterminé
  getDetailsMessage(id: number): Observable<MessagesComplexe> {
    return this.http.get<MessagesComplexe>(this.APIUrl + '/Messages/DetailsMessage/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

    // HttpClient API get() method => Get/Fetch Message déterminé
    getDetailsMessageComplet(id: number): Observable<MessagesComplet> {
      return this.http.get<MessagesComplet>(this.APIUrl + '/Messages/DetailsMessage/' + id)
        .pipe(
          retry(1),
          catchError(this.handleError)
        )
    }

  // HttpClient API post() method => Créer un nouveau Message
  creerMessageRetry(message: MessagesToCreate) {
    return this.http.post<MessagesToCreate>(this.APIUrl + '/Messages/CreerMessageRetry/' + message, JSON.stringify(message), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe((result) => { });
  }

  // HttpClient API put() method => Modifier un Message
  modifierMessage(id: number, message: Messages) {
    return this.http.put<Messages>(this.APIUrl + '/Messages/ModifierMessage/' + id, JSON.stringify(message), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => Supprimer un Message
  supprimerMessage(id: number) {
    return this.http.delete<Messages>(this.APIUrl + '/Messages/SupprimerMessage/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

    // HttpClient API delete() method => Supprimer un Message
    supprimerMessageBIS(id: number) {
      return this.http.delete(this.APIUrl + '/Messages/SupprimerMessageBIS/' + id, this.httpOptions)
        .pipe(
          retry(1),
          catchError(this.handleError)
        )
    }

    supprimerMessageById(idMessage: number): Observable<null> {
      return this.http.delete(`backendapi/Messages/supprimermessagebyid/${idMessage}`).pipe(
        retry(1),
        catchError((error) => this.handleErrorBIS(error, null))
      );
    }

  // HttpClient API delete() method => Supprimer un Message
  supprimerMessageTER(id: number) {
    return this.http.delete(this.APIUrl + '/Messages/SupprimerMessage/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      );
  }

    // HttpClient API delete() method => Supprimer un Message
  supprimerMessageDirecte(id: Number) {
    return this.http.delete(this.APIUrl + '/Messages/SupprimerMessageDirecte/' + id, this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  //**************/
  // Destinations //
  //**************//


  // HttpClient API get() method => Get/Fetch ListeAllDestinations
  getListeAllDestinations(): Observable<Destinations> {
    return this.http.get<Destinations>(this.APIUrl + '/Destinations/ListeAllDestinations')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch Destination déterminé
  getDetailsDestination(id: number): Observable<Destinations> {
    return this.http.get<Destinations>(this.APIUrl + '/Destinations/DetailsDestination/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => Créer une nouvelle destination
  creerDestination(destination : Destinations) {
    return this.http.post(this.APIUrl + '/Destinations/CreerDestination/'+ destination, JSON.stringify(destination), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe( (result) => { });
  }

  //************/
  //Utilisateurs//
  //************//


  // HttpClient API get() method => Get/Fetch ListeAllUtilisateurs
  getListeAllUtilisateurs(): Observable<Utilisateurs> {
    return this.http.get<Utilisateurs>(this.APIUrl + '/Utilisateurs/ListeAllUtilisateurs')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch Utilisateur déterminé
  getDetailsUtilisateur(id: number): Observable<Utilisateurs> {
    return this.http.get<Utilisateurs>(this.APIUrl + '/Utilisateurs/DetailsUtilisateur/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => Créer un nouvel Utilisateur
  creerUtilisateur(utilisateur:Utilisateurs) {
    return this.http.post(this.APIUrl + '/Utilisateurs/CreerUtilisateur/' + utilisateur, JSON.stringify(utilisateur), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe((result) => { });
  }

  // HttpClient API put() method => Modifier un Utilisateur
  modifierUtilisateur(id: number, utilisateur: Utilisateurs) {
    return this.http.put<Utilisateurs>(this.APIUrl + '/Utilisateurs/ModifierUtilisateur/' + id + utilisateur, JSON.stringify(utilisateur), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => Supprimer un Utilisateur
  supprimerUtilisateur(id: number) {
    return this.http.delete<Utilisateurs>(this.APIUrl + '/Utilisateurs/SupprimerUtilisateur/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //********/
  // Pieces //
  //*******//


  // HttpClient API get() method => Get/Fetch ListeAllPieces
  getListeAllPieces(): Observable<Photos> {
    return this.http.get<Photos>(this.APIUrl + '/Photos/listeallphotos/')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //*********/
  // Annexes //
  //*********//


  // HttpClient API get() method => Get/Fetch ListeAllAnnexes
  getListeAllAnnexes(): Observable<Annexes> {
    return this.http.get<Annexes>(this.APIUrl + '/Annexes/listeallannexes/')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //*****************/
  // TypesMessages //
  //****************/

  // HttpClient API get() method => Get/Fetch ListeTypesMessage
  getListeTypesMessage(): Observable<TypesMessage> {
    return this.http.get<TypesMessage>(this.APIUrl + '/TypesMessages/ListeTypesMessage')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  //**************/
  // Coproprietes //
  //**************//


  // HttpClient API get() method => Get/Fetch ListeAllCoproprietes
  getListeAllCoproprietes(): Observable<Coproprietes> {
    return this.http.get<Coproprietes>(this.APIUrl + '/Coproprietes/ListeAllCoproprietes')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch Copropriete déterminé
  getDetailsCopropriete(id: number): Observable<Coproprietes> {
    return this.http.get<Coproprietes>(this.APIUrl + '/Coproprietes/DetailsCoproprietes/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => Créer une nouvelle Copropriete
  creerCopropriete(copropriete: Coproprietes) {
    return this.http.post(this.APIUrl + '/Coproprietes/CreerCopropriete/' + copropriete, JSON.stringify(copropriete), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe((result) => { });
  }

  // HttpClient API put() method => Modifier une Copropriete
  modifierCopropriete(id: number, copropriete: Coproprietes) {
    return this.http.put<Coproprietes>(this.APIUrl + '/Coproprietes/ModifierCopropriete/' + id + copropriete, JSON.stringify(copropriete), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => Supprimer une Copropriete
  supprimerCopropriete(id: number) {
    return this.http.delete<Coproprietes>(this.APIUrl + '/Coproprietes/SupprimerCopropriete/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //*****************/
  // Coproprietaires //
  //****************//


  // HttpClient API get() method => Get/Fetch ListeAllCoproprietaires
  getListeAllCoproprietaires(): Observable<Coproprietaires> {
    return this.http.get<Coproprietaires>(this.APIUrl + '/Coproprietaires/ListeAllCoproprietaires')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch Coproprietaire déterminé
  getDetailsCoproprietaire(id: number): Observable<Coproprietaires> {
    return this.http.get<Coproprietaires>(this.APIUrl + '/Coproprietaires/DetailsCoproprietaire/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => Créer un nouveau Coproprietaire
  creerCoproprietaire(coproprietaire: Coproprietaires) {
    return this.http.post(this.APIUrl + '/Coproprietaires/CreerCoproprietaires/' + coproprietaire, JSON.stringify(coproprietaire), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe((result) => { });
  }

  // HttpClient API put() method => Modifier un Coproprietaire
  modifierCoproprietaire(id: number, coproprietaire: Coproprietaires) {
    return this.http.put<Coproprietaires>(this.APIUrl + '/Coproprietaires/ModifierCoproprietaire/' + id + coproprietaire, JSON.stringify(coproprietaire), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => Supprimer un Coproprietaire
  supprimerCoproprietaire(id: number) {
    return this.http.delete<Coproprietaires>(this.APIUrl + '/Coproprietaires/SupprimerCoproprietaire/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //*******/
  // Lots //
  //******//


  // HttpClient API get() method => Get/Fetch ListeAllLots
  getListeAllLots(): Observable<Lots> {
    return this.http.get<Lots>(this.APIUrl + '/Lots/ListeAllLots')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch Lot déterminé
  getDetailsLot(id: number): Observable<Lots> {
    return this.http.get<Lots>(this.APIUrl + '/Lots/DetailsLots/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => Créer un nouveau Lot
  creerLot(lot: Lots) {
    return this.http.post(this.APIUrl + '/Lots/CreerLot/' + lot, JSON.stringify(lot), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe((result) => { });
  }

  // HttpClient API put() method => Modifier un Lot
  modifierLot(id: number, lot: Lots) {
    return this.http.put<Lots>(this.APIUrl + '/Lots/ModifierLot/' + id + lot, JSON.stringify(lot), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => Supprimer un Lot
  supprimerLot(id: number) {
    return this.http.delete<Lots>(this.APIUrl + '/Lots/SupprimerLot/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

//PAS BON!...
  // HttpClient API get() method => Get/Fetch ListeAllLots by another way
  /*getListeAllLotsAnotherWay() {
    return this.http.get<[]>(this.APIUrl + '/Lots/ListeAllLots')
      .pipe(map (data => {
        this.lots = data; 
        return;
      }),
      retry(1),
      catchError(this.handleError)
      )
  }*/


  //*************/
  // Occupations //
  //*************//

 
  // // HttpClient API get() method => Get/Fetch ListeAllOccupations
  // getListeAllOccupations(): Observable<Occupation> {
  //   return this.http.get<Occupation>(this.APIUrl + '/Occupations/ListeAllOccupations')
  //     .pipe(
  //       retry(1),
  //       catchError(this.handleError)
  //     )
  // }

  // // HttpClient API get() method => Get/Fetch Occupation déterminé
  // getDetailsOccupation(id: number): Observable<Occupation> {
  //   return this.http.get<Occupation>(this.APIUrl + '/Occupations/DetailsOccupation/' + id)
  //     .pipe(
  //       retry(1),
  //       catchError(this.handleError)
  //     )
  // }

  // // HttpClient API post() method => Créer une nouvelle Occupation
  // creerOccupation(occupation: Occupation) {
  //   return this.http.post(this.APIUrl + '/Occupations/CreerOccupation' + occupation, JSON.stringify(occupation), this.httpOptions)
  //     .pipe(retry(1), catchError(this.handleError))
  //     .subscribe((result) => { });
  // }

  // // HttpClient API put() method => Modifier une Occupation
  // modifierOccupation(id: number, occupation: Occupation) {
  //   return this.http.put<Occupation>(this.APIUrl + '/Occupations/ModifierOccupation/' + id + occupation, JSON.stringify(occupation), this.httpOptions)
  //     .pipe(
  //       retry(1),
  //       catchError(this.handleError)
  //     )
  // }

  // // HttpClient API delete() method => Supprimer une Occupation
  // supprimerOccupation(id: number) {
  //   return this.http.delete<Occupation>(this.APIUrl + '/Occupations/SupprimerOccupation/' + id, this.httpOptions)
  //     .pipe(
  //       retry(1),
  //       catchError(this.handleError)
  //     )
  // }

  //*****************//
  // LignesDecomptes //
  //*****************//


  // HttpClient API get() method => Get/Fetch ListeAllLignesDecomptes
  getListeAllLignesDecomptes(): Observable<LignesDecomptes> {
    return this.http.get<LignesDecomptes>(this.APIUrl + '/LignesDecomptes/ListeAllLignesDecomptes')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method => Get/Fetch LignesDecomptes déterminé
  getDetailsLignesDecomptes(id: number): Observable<LignesDecomptes> {
    return this.http.get<LignesDecomptes>(this.APIUrl + '/LignesDecomptes/DetailsLignesDecomptes/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => Créer un nouveau LignesDecomptes
  creerLignesDecomptes(livreClient: LignesDecomptes) {
    return this.http.post(this.APIUrl + '/LignesDecomptes/CreerLignesDecomptes' + livreClient, JSON.stringify(livreClient), this.httpOptions)
      .pipe(retry(1), catchError(this.handleError))
      .subscribe((result) => { });
  }

  // HttpClient API put() method => Modifier un LignesDecomptes
  modifierLignesDecomptes(id: number, ligneDecompte: LignesDecomptes) {
    return this.http.put<LignesDecomptes>(this.APIUrl + '/LignesDecomptes/ModifierLignesDecomptes/' + id + ligneDecompte, JSON.stringify(ligneDecompte), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => Supprimer un LignesDecomptes
  supprimerLivreClient(id: number) {
    return this.http.delete<LignesDecomptes>(this.APIUrl + '/LignesDecomptes/SupprimerLignesDecomptes/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  //************/
  // Paiements //
  //***********/




  //***************/
  // Fournisseurs  //
  //***************/


  //Page Gestion-Dashboard//

  //Page Gestion-Acp//

  //Page Gestion-Copropriete//

  //Page Gestionn-Coproprietaires//

  //Page Gestion-Lots//

  //Page Gestion-Occupations//

  //Page Gestion-CompteBqueAcp//

  //Page Gestion-Fournisseurs//

  //Page Gestion-LivreFournisseur//

  //Page Gestion-LivrePmt

  //Page Gestion-LivreClient//

  /*=========================================================
   * Gestion des erreurs sur calls apis / consommation apis *
   =========================================================*/

  // Error handling 
  handleError(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Erreur! : ${error.status}\nMessage d'erreur: ${error.message} Votre connexion avec le server est peut-être interrompue!`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

  
    // private log(response: any) {
    //   console.table(response);
    // }
  
    private handleErrorBIS(error: Error, errorValue: any) {
      console.error(error);
      return of(errorValue);
    }

}



