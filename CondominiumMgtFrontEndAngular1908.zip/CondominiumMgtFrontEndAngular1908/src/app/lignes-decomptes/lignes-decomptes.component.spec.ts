import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LignesDecomptesComponent } from './lignes-decomptes.component';

describe('LignesDecomptesComponent', () => {
  let component: LignesDecomptesComponent;
  let fixture: ComponentFixture<LignesDecomptesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LignesDecomptesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LignesDecomptesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
