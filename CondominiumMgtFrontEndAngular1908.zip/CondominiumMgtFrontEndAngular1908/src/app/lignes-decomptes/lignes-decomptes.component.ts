import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lignes-decomptes',
  templateUrl: './lignes-decomptes.component.html',
  styleUrls: ['./lignes-decomptes.component.css']
})
export class LignesDecomptesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
