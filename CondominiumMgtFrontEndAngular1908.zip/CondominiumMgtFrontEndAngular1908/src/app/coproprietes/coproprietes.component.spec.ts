import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoproprietesComponent } from './coproprietes.component';

describe('CoproprietesComponent', () => {
  let component: CoproprietesComponent;
  let fixture: ComponentFixture<CoproprietesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoproprietesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoproprietesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
