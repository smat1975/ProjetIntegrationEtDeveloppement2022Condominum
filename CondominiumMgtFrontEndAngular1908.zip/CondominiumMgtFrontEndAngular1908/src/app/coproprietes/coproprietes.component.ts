import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coproprietes',
  templateUrl: './coproprietes.component.html',
  styleUrls: ['./coproprietes.component.css']
})
export class CoproprietesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
