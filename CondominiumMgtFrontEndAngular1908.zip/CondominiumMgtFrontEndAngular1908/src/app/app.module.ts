import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

//import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
/* PAS POUR L'INSTANT import { NgbModule } from '@ng-bootstrap/ng-bootstrap';*/
/* PAS UTILES import { MatSliderModule } from '@angular/material/slider';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';*/
/*//import { ToastrModule } from './angular-toastr';*/
import { CommonModule } from '@angular/common';
/*PAS UTILES import { ToastrModule } from 'ngx-toastr';
import { JwtModule } from '@auth0/angular-jwt';*/
/*PAS POur L'INSTANT import { AuthentificationService } from './services/authentification.service';
import { AuthgardService } from './services/authgard.service';*/
import { MessagesModule } from './messages/messages.module';
import { SharedService } from './services/shared.service';

/*import { CallApiComponent } from '../call-api/call-api.component';*/
import { HomeComponent } from './home/home.component';
//import { ListMessagesComponent } from './messages/list-messages/list-messages.component';
import { MessagesListeComponent } from './messages/messages-liste/messages-liste.component';
//import { EditMessagesComponent } from './messages/edit-messages/edit-messages.component';
import { MessagesComponent } from './messages/messages.component';
//import { MessagesAjouterComponent } from './messages/messages-ajouter/messages-ajouter.component';
//import { MessagesModifierComponent } from './messages/messages-modifier/messages-modifier.component';
import { MessagesSupprimerComponent } from './messages/messages-supprimer/messages-supprimer.component';
import { MessagesDetailsComponent } from './messages/messages-details/messages-details.component';
import { MessagesAjouterComponent } from './messages/messages-ajouter/messages-ajouter.component';
import { MessagesModifierComponent } from './messages/messages-modifier/messages-modifier.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AjouterMessagesComponent } from './messages/ajouter-messages/ajouter-messages.component';
/*import { MessagesConfirmationComponent } from './messages/messages-confirmation/messages-confirmation.component';*/
/*Plus ICI!!!! import { MessagesFormComponent } from './messages/messages-form/messages-form.component'; */
/*Plus ICI!!!! import { DetailsMessagesComponent } from './messages/details-messages/details-messages.component'; //Peut-être à enlever????!!!!*/
//import { MessagesModule } from './messages/messages.module';
//import { UtilisateursComponent } from './utilisateurs/utilisateurs.component';
/*import { UtilisateurAjouterComponent } from '../utilisateur/utilisateur-ajouter/utilisateur-ajouter.component';
import { GestionComponent } from '../gestion/gestion.component';
import { GestionValvesComponent } from '../gestion/gestion-valves/gestion-valves.component';
import { GestionUserCoproprietairesComponent } from '../gestion/gestion-user-coproprietaires/gestion-user-coproprietaires.component';
import { GestionLotsComponent } from '../gestion/gestion-lots/gestion-lots.component';
import { GestionOccupationComponent } from '../gestion/gestion-occupation/gestion-occupation.component';
import { GestionRdvComponent } from '../gestion/gestion-rdv/gestion-rdv.component';
import { GestionSujetsAcpComponent } from '../gestion/gestion-sujets-acp/gestion-sujets-acp.component';
import { GestionPhotosComponent } from '../gestion/gestion-photos/gestion-photos.component';
import { LoadingComponent } from '../loading/loading.component';
import { LoginComponent } from '../login/login.component';
import { NotFoundComponent } from '../not-found/not-found.component';
import { TestSelectComponent } from './test-select/test-select.component';
import { AdminComponent } from '../admin/admin.component';
import { AdminMessagesComponent } from '../admin/admin-messages/admin-messages.component';
import { AdminValvesComponent } from '../admin/admin-valves/admin-valves.component';
import { UserComponent } from '../user/user.component';
import { DestinationsComponent } from '../destinations/destinations.component';
import { DestinationsAjouterComponent } from '../destinations/destinations-ajouter/destinations-ajouter.component';
import { GestionCoproprieteComponent } from '../gestion/gestion-coproriete/gestion-copropriete.component';
import { GestionCoproprieteAjouterComponent } from '../gestion/gestion-coproriete/gestion-copropriete-ajouter/gestion-copropriete-ajouter.component';
*/

@NgModule({
  declarations: [
    HomeComponent,
    AppComponent,
    //AjouterMessagesComponent,
    //MessagesListeComponent,
    //MessagesDetailsComponent,
    //MessagesComponent,
    //MessagesAjouterComponent,
    //MessagesModifierComponent,
    // MessagesFormComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    FormsModule,
    //ToastrModule,
    CommonModule,
    /*RouterModule*/
    MessagesModule,
    AppRoutingModule,
    BrowserAnimationsModule
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
