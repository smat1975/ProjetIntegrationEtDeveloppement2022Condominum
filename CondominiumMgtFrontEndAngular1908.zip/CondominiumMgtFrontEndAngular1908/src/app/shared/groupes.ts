export class Groupes {
    constructor(
        public idGroupe : number,
        public denomination : string,
        public description : string,
        public remarque : string,
        ) { }
}
