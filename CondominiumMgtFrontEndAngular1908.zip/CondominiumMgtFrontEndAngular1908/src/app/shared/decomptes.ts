export class Decomptes {
    constructor(
        public idDecompte : number,
        public idCoproprietaire : string,
        public idGroupement : number,
        public idPeriode : number,
        public dateCreation : Date,
        public dateDebutDecompte : Date,
        public dateFinDecompte  : Date,
        public idTypeTva : number,
        public montantTotalTva : number,
        public dateEcheance : Date,
        public referencePaiement : string,
        public commentaire : string,
        public soldeON : boolean,
        public remarque : string,
        public montantTotalDecompte?: number,
        ) { }
}
