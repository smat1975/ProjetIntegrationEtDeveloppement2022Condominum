export class Fournisseurs {
    constructor(
        public idFournisseur : number,
        public denomination : string,
        public nomContact : string,
        public adresse : string,
        public email : string,
        public numTel : string,
        public numGsm : string,
        public numTva :string,
        public activite : string,
        public numAgregation :string,
        public description : string,
        public remarque : string,
        public dateDebut : Date,
        public dateFin?: Date,
        ) { }

}