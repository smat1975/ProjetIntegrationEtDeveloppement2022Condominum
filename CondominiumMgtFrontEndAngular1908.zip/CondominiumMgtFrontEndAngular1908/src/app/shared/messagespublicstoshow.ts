export class MessagesPublicsToShow {
  constructor(
        contenuMessage : string,
        dateExpedition : Date,
        //email : string,
  ) { }
}
