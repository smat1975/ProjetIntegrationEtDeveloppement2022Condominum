import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-decompteslist',
  templateUrl: './decompteslist.component.html',
  styleUrls: ['./decompteslist.component.css']
})
export class DecompteslistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
