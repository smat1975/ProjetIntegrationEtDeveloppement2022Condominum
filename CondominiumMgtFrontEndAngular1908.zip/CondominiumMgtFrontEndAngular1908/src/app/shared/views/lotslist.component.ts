import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lotslist',
  templateUrl: './lotslist.component.html',
  styleUrls: ['./lotslist.component.css']
})
export class LotslistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
