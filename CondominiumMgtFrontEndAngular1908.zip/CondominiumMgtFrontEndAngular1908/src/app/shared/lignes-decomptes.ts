export class LignesDecomptes {
    constructor(
        public idLigneDecompte : number,
        public idDecompte : number,
        public description : string,
        public idLigneDocumentFournisseur : number,
        public remarque : string,
        public idCodePcmn?: number,
        public idQuotite?: number,
        public dateDebutLigne?: Date,
        public dateFinLigne?: Date,
        public nbreJoursLigne? : number,
        public montantTotalTvacligne? : number,
        public montantTvaligne?: number,
        ) { }
}

