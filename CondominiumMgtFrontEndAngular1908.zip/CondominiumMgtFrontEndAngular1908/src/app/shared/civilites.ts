export class Civilites {
    constructor(
        public idCivilite : number,
        public denomination : string,
        public remarque : string,
      ) { }
}
