export class Paiements {
    constructor(
        public idPaiement : number,
        public idCompteBquePayeur : number,
        public nomPayeurAutre : string,
        public communication : string,
        public montant : number,
        public dateEnregistrement : Date,
        public dateDocument : Date,
        public numDocument : string,
        public remarque : string,
        ) { }


}
