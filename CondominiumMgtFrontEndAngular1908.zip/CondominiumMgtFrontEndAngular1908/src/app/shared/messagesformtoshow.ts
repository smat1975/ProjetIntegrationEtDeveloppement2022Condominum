export class MessagesFormToShow {
  constructor(      
        titreMessage: string,
        contenuMessage: string,
        idTypeMessage: string,
        validation?: boolean,
        idMessage?: number,
  ) { }
}
