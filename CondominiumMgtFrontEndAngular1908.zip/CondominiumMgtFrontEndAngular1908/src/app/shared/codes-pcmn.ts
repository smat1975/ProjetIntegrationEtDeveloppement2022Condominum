export class CodesPcmn {    
    constructor(
                public idCodePcmn : number,
                public codePcmn : number,
                public libelle : string,
                public codeDecompte : number,
                public denomination : string,
                public remarque : string,
  ) { }
}
