export class TypesLot {
    constructor(
        public idTypeLot : number,
        public denomination: string,
        public description : string,
        public remarque : string,
        ) { }
}

