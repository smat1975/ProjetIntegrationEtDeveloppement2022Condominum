export class TypesMessage {
    constructor(
        public idTypeMessage : number,
        public denomination: string,
        public description : string,
        public remarque? : string,
        ) { }
}


// export const TypesMessageSelect: TypesMessage[] = [
//     { idTypeMessage: 1, denomination: 'Avertissement', description: 'Avertissement' },
//     { idTypeMessage: 2, denomination: 'Information', description: 'Information' },
//     { idTypeMessage: 3, denomination: 'Appel', description: 'Appel' },
//     { idTypeMessage: 4, denomination: 'Rappel', description: 'Rappel' },
//     { idTypeMessage: 5, denomination: 'Message publique', description: 'Message publique' },
//   ];