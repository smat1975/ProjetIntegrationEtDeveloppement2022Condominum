export class Annexes {
  constructor(
      public idAnnexe : number,
      public idMessage : number,
      public remarque : string,

      // public annexeIdPhoto: number,
      // public annexePhotoRessource: string
    ) { }
}
