export class Groupements {
    constructor(
        public idGroupement : number,
        public idGroupe : number,
        public idLot : number,
        public remarque : string,
        public dateDebutGroupement?: Date,
        public dateFinGroupement?: Date,
        ) { }
}
