export class LignesDocumentsFournisseurs {
    constructor(
        public idLigneDocumentFournisseur : number,
        public idDocumentFournisseure : number,
        public idCodePcmn : number,
        public description : string,
        public remarque : string,
        public dateDebutLigne?: Date,
        public dateFinLigne?: Date,
        public nbreJoursLigne? : number,
        public montantTotalTvacligne? : number,
        public montantTvaligne?: number,
        ) { }
}

