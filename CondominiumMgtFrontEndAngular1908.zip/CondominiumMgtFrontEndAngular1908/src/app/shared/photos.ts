export class Photos {
    constructor(
        public idPhoto : number,
        public idAnnexe : number,
        public ressource : string,
        ) { }
}
