export class DestinationToCreate {
  constructor(
    public idCoproprietaire : string,
    public idMessage : number,
  ) { }
}
