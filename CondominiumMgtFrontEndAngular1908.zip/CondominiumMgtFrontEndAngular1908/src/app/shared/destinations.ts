export class Destinations {
    constructor(
        public idDestination : number,
        public idMessage : number,
        public idDestinataire : number,
        ) { }

}
