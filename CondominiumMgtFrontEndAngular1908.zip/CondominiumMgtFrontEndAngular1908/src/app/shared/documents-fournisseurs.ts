import { NumberFormatStyle } from "@angular/common";

export class DocumentsFournisseurs {
    constructor(
        public idDocumentFournisseur : number,
        public idTypeDocumentFournisseur : NumberFormatStyle,
        public idFournisseur : number,
        public description : string,
        public montantTotalTvacdocument : number,
        public dateEnregistrement : Date,
        public dateDocument : Date,
        public remarque : string,
        public idPeriode?: number,
        public idTypeTva?: number,
        public montantTva?: number,
        public dateEcheance?: Date,
        ) { }
}
