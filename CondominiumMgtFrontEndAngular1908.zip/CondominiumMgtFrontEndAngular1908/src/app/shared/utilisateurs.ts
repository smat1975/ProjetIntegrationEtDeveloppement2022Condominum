export class Utilisateurs {
  constructor(
    public idUtilisateur : string,
    public nomUtilisateur : string,
    public prenomsUtilisateur : string,
    public emailUtilisateur : string,
    public dateNaissanceUtilisateur : Date,
    public dateCreationUtilisateur : Date,
    public idTypeUtilisateur: string,
    public remarque: string,
    public dateDebut: Date,
    public dateFin? : Date
  ) { }
}
// Ce sont tous les coproprietaires + les différents membres autorisés(et authentifiés) du Syndic.