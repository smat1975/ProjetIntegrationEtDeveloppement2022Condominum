export class Localisations {
    constructor(
        public idLocalisation : number,
        public adresse : string,
        public codeLocalisation : string,
        public description : string,
        public remarque : string,
        public dateDebut : Date,
        public dateFin?: Date,
        ) { }
}

