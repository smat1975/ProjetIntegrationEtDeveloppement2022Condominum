export class TypesDocumentFournisseur {
    constructor(
        public idTypeDocumentFournisseur : number,
        public denomination: string,
        public description : string,
        public remarque : string,
        ) { }
}
