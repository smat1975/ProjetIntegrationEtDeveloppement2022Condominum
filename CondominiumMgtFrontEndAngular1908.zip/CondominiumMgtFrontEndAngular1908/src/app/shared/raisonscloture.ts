export class RaisonsCloture {
    constructor(
        public idRaisonCloture : number,
        public denomination: string,
        public description : string,
        public remarque : string,
        ) { }
}
