export class MessagesUtilisateurToShow {
  constructor(
        dateExpedition : Date,
        contenuMessage : string,
        //email : string
  ) { }
}
