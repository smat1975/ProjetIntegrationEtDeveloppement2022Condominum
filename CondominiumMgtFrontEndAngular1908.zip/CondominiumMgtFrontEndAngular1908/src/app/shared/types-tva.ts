export class TypesTva {
    constructor(
        public idTypeTva: number,
        public denomination: string,
        public description : string,
        public remarque : string,
        public actifON?: boolean,
        ) { }
}
