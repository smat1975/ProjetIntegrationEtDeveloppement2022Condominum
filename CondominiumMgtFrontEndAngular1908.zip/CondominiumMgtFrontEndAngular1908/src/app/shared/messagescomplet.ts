export class MessagesComplet {
      constructor(
      public idMessage: number,
      public idExpediteur: string,
      public dateExpedition: Date,
      public titreMessage: string,
      public contenuMessage: string,
      public idTypeMessage: number,
      public annexes: any[],
      public destinations: any[],
      public validation?: boolean,
      public idExpediteurNavigation?: any,
      public idTypeMessageNavigation?: any,
) {}
}

//Version avant passage par json2ts
    /*constructor(
        public idMessage: number,
        public idExpediteur: string,
        public dateExpedition: Date,
        public titreMessage: string,
        public contenuMessage: string,
        public idTypeMessage: number,
        public annexes: Array<string>,
        public destination: Array<string>,
        public validation?: boolean,
        public idExpediteurNavigation?: number,
        public idTypeMessageNavigation?: number,
      ) { }*/
      