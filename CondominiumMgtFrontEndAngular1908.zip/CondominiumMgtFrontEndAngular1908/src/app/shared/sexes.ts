export class Sexes {
    constructor(
        public idSexe : number,
        public denomination: string,
        public remarque : string,
        ) { }
}

