export class MatchingsPaiements {
    constructor(
        public idMatchingPaiement : number,
        public idDecompte : number,
        public idPaiement  : number,
        public montant : number,
        public dateEnregistrement : Date,
        public remarque : string,
        ) { }
}
