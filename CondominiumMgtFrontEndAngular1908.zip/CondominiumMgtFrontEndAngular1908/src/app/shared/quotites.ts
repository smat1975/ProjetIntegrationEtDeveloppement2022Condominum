export class Quotites {
    constructor(
        public idQuotite: number,
        public idLot : number,
        public idLocalisation : number,
        public valeurLot : number,
        public valeurLocalisation: number,
        public remarque : string,
        public dateDebut : Date,
        public dateFin?: Date,
        public actifON?: boolean,
        ) { }
}
