export class ComptesBque {
    constructor(
        public idCompteBque : number,
        public nomBque : string,
        public numCompteBque : string,
        public idCoproprietaire : string,
        public description : string,
        public actifON : boolean,
        public remarque : string,
      ) { }
}
