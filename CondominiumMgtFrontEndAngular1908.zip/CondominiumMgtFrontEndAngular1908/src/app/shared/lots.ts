export class Lots {
    constructor(
        public idLot  : number,
        public idTypeLot : number,
        public codeLotdLot : string,
        public idLocalisation : number,
        public descriptiont : string,
        public nombreM2 : number,
        public remarque : string,
        public dateDebut : Date,
        public dateFin?: Date,
        ) { }
}
