import { Annexes } from "./annexes";
import { Destinations } from "./destinations";

export class Messages {
  idMessage: number;
  idExpediteur: string;
  dateExpedition: Date;
  titreMessage: string;
  contenuMessage: string;
  idTypeMessage: number;
  annexes: Annexes[];
  destinations: Destinations[];
  validation?: boolean
    constructor(
        idMessage: number,
        idExpediteur: string,
        dateExpedition: Date = new Date(),
        titreMessage: string = 'Entrez le titre du message',
        contenuMessage: string = 'Entrez ici le contenu du message',
        idTypeMessage: number,
        annexes: Annexes[] = [],
        destinations: Destinations[] = [],
        validation?: boolean
      ) {
        this.idMessage = idMessage;
        this.idExpediteur = idExpediteur;
        this.dateExpedition = dateExpedition;
        this.titreMessage = titreMessage;
        this.contenuMessage = contenuMessage;
        this.idTypeMessage = idTypeMessage;
        this.annexes = annexes;
        this.destinations = destinations;
        this.validation = validation
       }
}

// constructor(
//         public idMessage: number,
//         public idExpediteur: string,
//         public dateExpedition: Date,
//         public titreMessage: string,
//         public contenuMessage: string,
//         public idTypeMessage: number,
//         public validation?: boolean
// ){}
// constructor(
// idMessage: number,
// idExpediteur: string,
// dateExpedition: Date,
// titreMessage: string,
// contenuMessage: string,
// idTypeMessage: number,
// validation?: boolean
// ){}
// }
// export class Messages {
//   idMessage: number;
//   idExpediteur: string;
//   dateExpedition: Date;
//   titreMessage: string;
//   contenuMessage: string;
//   idTypeMessage: number;
//   validation?: boolean
//     constructor(
//         idMessage: number,
//         idExpediteur: string,
//         dateExpedition: Date = new Date(),
//         titreMessage: string = 'Entrez le titre du message',
//         contenuMessage: string = 'Entrez ici le contenu du message',
//         idTypeMessage: number = 2,
//         validation: boolean = true
//       ) {
//         this.idMessage = idMessage;
//         this.idExpediteur = idExpediteur;
//         this.dateExpedition = dateExpedition;
//         this.titreMessage = titreMessage;
//         this.contenuMessage = contenuMessage;
//         this.idTypeMessage = idTypeMessage;
//         this.validation = validation
//        }

// }
/*
constructor(
   public idMessage: number,
        public idExpediteur: string,
        public dateExpedition: Date,
        public titreMessage: string,
        public contenuMessage: string,
        public idTypeMessage: number,
        public validation?: boolean
){}
*/