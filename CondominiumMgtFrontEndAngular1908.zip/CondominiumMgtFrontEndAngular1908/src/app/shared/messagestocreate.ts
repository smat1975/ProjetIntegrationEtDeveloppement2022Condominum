export class MessagesToCreate {
  constructor(
    public idExpediteur: string,
    public titreMessage: string,
    public contenuMessage: string,
    public idTypeMessage: number,
    public annexes: any[],
    public destinations: any[],
    public validation?: boolean
  ) { }
}
