export class Coproprietes {
    constructor(
        public idCopropriete : number,
        public idCoproprietaire : string,
        public idLot : number,
        public numContrat : string,
        public remarque : string,
        public dateDebut : Date,
        public dateFin?: Date,
        ) { }
}
