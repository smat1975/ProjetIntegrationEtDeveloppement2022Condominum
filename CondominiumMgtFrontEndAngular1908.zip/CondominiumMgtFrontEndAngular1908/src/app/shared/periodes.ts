export class Periodes {
    constructor(
        public idPeriode: number,
        public denomination : string,
        public annee: string,
        public remarque : string,
        public dateDebut : Date,
        public dateFin?: Date,
        ) { }
}
