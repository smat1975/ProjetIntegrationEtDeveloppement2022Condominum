export class MessagesToShow {
  constructor(
        //expediteur: string,
        //email: string,
        dateExpedition: Date,
        titreMessage: string,
        contenuMessage: string,
        typeMessage: string,
        //lu: boolean,
        idMessage: number
  ) { }
}
