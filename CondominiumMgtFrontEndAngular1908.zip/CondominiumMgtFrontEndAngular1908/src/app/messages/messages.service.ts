import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SharedService } from 'src/app/services/shared.service';
import { Messages } from 'src/app/shared/messages';
import { MessagesToShow } from 'src/app/shared/messagestoshow';
import { MessagesFormToShow } from 'src/app/shared/messagesformtoshow';
import { TypesMessage } from 'src/app/shared/types-message';
import { ActivatedRoute } from '@angular/router';
import { OnInit, Output } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

//!\\ A SUPPRIMER!!!! //!\\

export class MessagesService {

  @Output() message!: Messages
      
 /* APIUrl = "https://localhost:44392/backendapi";

        
      // Http Options
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }
*/
  constructor(private http: HttpClient,
  //private service: SharedService,
    private actRoute: ActivatedRoute
  ) { 
    /*this.idMessage = this.actRoute.snapshot.params.id;

    this.ListeAllMessages = this.service.getListeAllMessages().subscribe(data => {
      this.ListeAllMessages = data;
    });

    this.ListeTypesMessage = this.service.getListeTypesMessage().subscribe(data => {
      this.ListeTypesMessage = data;
    });*/
  }
  /*ListeAllMessages: /*Messages[]*//* any = [];

  ListeTypesMessage: /*TypesMessage[]*//* any = [];
  idMessage: any;*/

    //***********/
  // Messages //
  //**********//

    // HttpClient API get() method => Get/Fetch ListeAllMessages
    /*getListeAllMessages(): Observable<Messages> {
      return this.http.get<Messages>(this.APIUrl + '/Messages/listeallmessages/')
        .pipe(
          retry(1),
          catchError(this.handleError)
        )
    }
   */ 
  
  /*getMessagesList(): Messages[] {
      return this.service.getListeAllMessages().subscribe(data => {
      this.ListeAllMessages = data;
      });
    } C'est un service => peut faire çà!!!!*/

    /*=========================================================
   * Gestion des erreurs sur calls apis / consommation apis *
   =========================================================*/

  // Error handling 
  /*handleError(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Erreur! : ${error.status}\nMessage d'erreur: ${error.message} Votre connexion avec le server est peut-être interrompue!`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }*/
}
