/// <reference path="../../../../node_modules/@types/jasmine/index.d.ts" />
import { TestBed, async, ComponentFixture, ComponentFixtureAutoDetect } from '@angular/core/testing';
import { BrowserModule, By } from "@angular/platform-browser";
import { MessagesDetailsComponent } from './messages-details.component';

let component: MessagesDetailsComponent;
let fixture: ComponentFixture<MessagesDetailsComponent>;

describe('Messages-Details-Delete component', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ MessagesDetailsComponent ],
            imports: [ BrowserModule ],
            providers: [
                { provide: ComponentFixtureAutoDetect, useValue: true }
            ]
        });
        fixture = TestBed.createComponent(MessagesDetailsComponent);
        component = fixture.componentInstance;
    }));

    it('should do something', async(() => {
        expect(true).toEqual(true);
    }));
});
