import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/services/shared.service';
import { Messages } from 'src/app/shared/messages';
import { MessagesComplexe } from 'src/app/shared/messagescomplexe';
import { MessagesComplet } from 'src/app/shared/messagescomplet';
import { MessagesToShow } from 'src/app/shared/messagestoshow';
//import { TypesMessageSelect } from 'src/app/shared/types-message';

@Component({
    selector: 'app-messages-details',
    templateUrl: './messages-details.component.html',
    styleUrls: ['./messages-details.component.css']
})

export class MessagesDetailsComponent implements OnInit {

  //id = this.actRoute.snapshot.params['id'];
  //messageData: any = {};
  private _id!: number;
  message!: MessagesComplet;
  // message!: MessagesComplexe;
  annexes: any[] = [];
  destinations: any[] = []; 

   constructor(
     public service: SharedService,
     public router: Router,
     private actRoute: ActivatedRoute,
  ) { }


  ngOnInit() {
    this.actRoute.paramMap.subscribe(params => {
      this._id = this.actRoute.snapshot.params['id'];
      //this._id = +params.get('id');
      // this.service.getDetailsMessage(this._id).subscribe(
      this.service.getDetailsMessageComplet(this._id).subscribe(
        (message) => this.message = message,
        (err: any) => console.log(err)
      );
    });
  }


}
