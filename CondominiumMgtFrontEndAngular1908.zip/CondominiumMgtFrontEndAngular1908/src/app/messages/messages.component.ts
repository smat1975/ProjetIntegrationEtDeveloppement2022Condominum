import { Component, OnInit, Output } from '@angular/core';
import { FormsModule, FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/services/shared.service';
// import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute } from '@angular/router';
import { Messages } from 'src/app/shared/messages';
//import { MessagesFormToShow } from 'src/app/shared/messagesformtoshow';
import { MessagesService } from './messages.service';
//import { MessagesFormComponent } from 'src/app/messages/messages-form/messages-form.component';
//import { MessagesListeComponent } from 'src/app/messages/messages-liste/messages-liste.component';
//import { MessagesDetailsComponent } from 'src/app/messages/messages-details/messages-details.component';
//import { MessagesAjouterComponent } from 'src/app/messages/messages-ajouter/messages-ajouter.component';
//import { MessagesModifierComponent } from 'src/app/messages/messages-modifier/messages-modifier.component';
//import { MessagesSupprimerComponent } from 'src/app/messages/messages-supprimer/messages-supprimer.component';


@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})



export class MessagesComponent implements OnInit {

  /*Ancienne version*/
  @Output() message!: Messages

  constructor(private service: SharedService,
    //private Mservice: MessagesService,
    private actRoute: ActivatedRoute
    /*Ancienne version supprimée
    //prioriteselect = PrioriteSelect,
    //typemessageselect = TypeMessageSelect,*/
  ) { 
    this.idMessage = this.actRoute.snapshot.params.id;
    this.ListeAllMessages = this.service.getListeAllMessages().subscribe(data => {
      this.ListeAllMessages = data;
    });
  }

  /*Ancienne version*/
  ListeAllMessages: /*Messages[]*/ any = [];

  idMessage: any

  ngOnInit(): void {
    this.actRoute.paramMap.subscribe(params => { this.idMessage = params.get('id') });
    /*//Ancienne version supprimée*/ this.refreshListeAllMessages();
  }

  /*Ancienne version supprimée
    /*supprimerMessage(this.idMessage) {
    if (window.confirm('Etes-vous sûre de vouloir suupprimer ce message?')) {
      this.service.supprimerMessage(this.id).subscribe(data => {
        this.getListAllMessagesNonPublics()
      })
    }
  }*/

  /*//Ancienne version supprimée*/

  refreshListeAllMessages() {
    this.service.getListeAllMessages().subscribe(data => {
      this.ListeAllMessages = data;
    });
  }
}
