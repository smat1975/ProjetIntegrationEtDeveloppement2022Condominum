import { Component, OnInit, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { MessagesComponent } from '../messages.component';
import { SharedService } from 'src/app/services/shared.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MessagesService } from 'src/app/messages/messages.service';
import { Messages } from 'src/app/shared/messages';
import { MessagesFormToShow } from 'src/app/shared/messagesformtoshow';
import { TypesMessage } from 'src/app/shared/types-message';
//import { TypesMessageSelect } from 'src/app/shared/types-message';

@Component({
  selector: 'app-messages-form',
  templateUrl: './messages-form.component.html',
  styleUrls: ['./messages-form.component.css']
})
export class MessagesFormComponent implements OnInit {

  //@Input() messageForm!: MessagesFormToShow;
  @Input() message!: Messages;
  // isAddForm: boolean;

  private _id!: number;
  // ListeTypesMessage: any = []
  idMessage: any;

  // @Output() ListeTypesMessage!: TypesMessage;
  ListeTypesMessage = ["1", "2", "3", "4", "5"];

   constructor(
     public service: SharedService,
     public router: Router,
     private actRoute: ActivatedRoute,
    //  private typesMessage: typeof TypesMessageSelect
  ) { }

  ngOnInit(): void {
    /*this.ListeTypesMessage = this.service.getListeTypesMessage().subscribe(data => {
      this.ListeTypesMessage = data;
    });*/
    // this.ListeTypesMessage = this.typesMessage;
    // this.isAddForm = this.router.url.includes('add');
  }

  // hasTypeMessage(typeMessage: /*TypesMessage*/string) : boolean{
  //   //this.type = (this.message.idTypeMessage).toString();
  //   return (this.message.idTypeMessage).toString().includes(typeMessage);
  // }

  selectValidation($event: Event){
    const isChecked: boolean = ($event.target as HTMLInputElement).checked;
  }

  onSubmit(){
    console.log("Modifications effectuées!");
    this.router.navigate(["/messages-details/", this.message.idMessage]);
  }

  // onSubmit() {
  //   if(this.isAddForm) {
  //     this.service.addMessage(this.message)
  //       .subscribe((message: Messages) => this.router.navigate(['/messages-add/', message.idMessage]));
  //   } else {
  //     this.service.updateMessage(this.message)
  //       .subscribe(() => this.router.navigate(['/messages-update/', this.message.idMessage]));
  //   }
  // }

  goToMessagesList(){
    this.router.navigate(['/list-messages/']);
  }

}
