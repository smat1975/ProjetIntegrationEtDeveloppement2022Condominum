import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagesListeComponent } from './messages-liste.component';

describe('MessagesListeComponent', () => {
  let component: MessagesListeComponent;
  let fixture: ComponentFixture<MessagesListeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MessagesListeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagesListeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
