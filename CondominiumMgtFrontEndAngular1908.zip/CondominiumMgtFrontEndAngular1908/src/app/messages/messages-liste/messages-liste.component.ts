import { Component, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SharedService } from 'src/app/services/shared.service';
//import { MessagesService } from 'src/app/messages/messages.service';
// import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute } from '@angular/router';
import { Messages } from 'src/app/shared/messages';
import { MessagesComplexe } from 'src/app/shared/messagescomplexe';
import { MessagesComplet } from 'src/app/shared/messagescomplet'
import { TypesMessage } from 'src/app/shared/types-message';


@Component({
  selector: 'app-messages-liste',
  templateUrl: './messages-liste.component.html',
  styleUrls: ['./messages-liste.component.css']
})
export class MessagesListeComponent implements OnInit {

 /*Ancienne version supprimée*/
//  @Output() message!: MessagesComplexe
 @Output() message!: MessagesComplet

 /*//Méthode avant*/
//  ListeAllMessages: any = [];
// ListeAllMessagesComplexeToShow: any = [];
ListeAllMessagesCompletToShow: any = [];
listTypesMessage: TypesMessage[] = [];

 constructor(private service: SharedService,
  /*private Mservice: MessagesService,*/
   private actRoute: ActivatedRoute
 ) { 
   /*//Méthode avant*/
  //  this.ListeAllMessages = this.service.getListeAllMessages().subscribe(data => {
  //    this.ListeAllMessages = data;
  //  });
 }


 ngOnInit(): void {
      // /*//Méthode avant*/this.refreshListeAllMessages();
    // this.refreshListeAllMessagesComplexeToShow();
    this.refreshListeAllMessagesCompletToShow();
    this.listTypesMessage = this.service.listTypesMessage;
 }

/* Méthode avant*/
// refreshListeAllMessages() {
//    this.service.getListeAllMessages().subscribe(data => {
//      this.ListeAllMessages = data;
//    });
//  }

// refreshListeAllMessagesComplexeToShow() {
//    this.service.getListeAllMessagesComplexe().subscribe(data => {
//      this.ListeAllMessagesComplexeToShow = data;
//    });
//  }

 refreshListeAllMessagesCompletToShow() {
  this.service.getListeAllMessagesComplet().subscribe(data => {
    this.ListeAllMessagesCompletToShow = data;
  });
}

}


  