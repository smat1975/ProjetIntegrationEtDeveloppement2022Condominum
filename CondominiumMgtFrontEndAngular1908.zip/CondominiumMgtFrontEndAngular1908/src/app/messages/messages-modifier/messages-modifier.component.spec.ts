import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagesModifierComponent } from './messages-modifier.component';

describe('MessagesModifierComponent', () => {
  let component: MessagesModifierComponent;
  let fixture: ComponentFixture<MessagesModifierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MessagesModifierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagesModifierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
