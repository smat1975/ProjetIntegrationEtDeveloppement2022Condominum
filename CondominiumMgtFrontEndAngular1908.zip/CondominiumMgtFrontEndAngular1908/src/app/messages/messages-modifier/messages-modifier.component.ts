import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages';
import { SharedService } from 'src/app/services/shared.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-messages-modifier',
  templateUrl: './messages-modifier.component.html',
  styleUrls: ['./messages-modifier.component.css']
})
export class MessagesModifierComponent implements OnInit {
  // @Input() id!: number;
  @Input() titreMessage!: string;
  @Input() contenuMessage!: string;
  @Input() validation!: boolean;


  private _id!: number;
  message!: Messages;
  //messageForm = this.fb.group({
  //  //idUtilisateur: [''],
  //  titreMessage: [null, Validators.required],
  //  contenuMessage: [null, Validators.required],
  //  //idTypeMessage: [null, Validators.required],
  //});


  constructor(
    /*private fb: FormBuilder,*/
    private service: SharedService,
    private actRoute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.actRoute.paramMap.subscribe(params => {
      this._id = this.actRoute.snapshot.params['id'];
      //this._id = +params.get('id');
      this.service.getDetailsMessage(this._id).subscribe(
        (message) => /*this.message = message,*/
        console.log(this.message = message)
        //(err: any) => console.log(err)
      );
    });
  }


  onModifierMessage() {
    this.service.modifierMessage(this.message.idMessage, this.message).subscribe(
      (message) => { }
    );
    
  };

  //onSubmit(): void {
  //  this.message = <Messages>this.messageForm.value;
  //  this.service.modifierMessage(this._id, this.message);
  //}


}
