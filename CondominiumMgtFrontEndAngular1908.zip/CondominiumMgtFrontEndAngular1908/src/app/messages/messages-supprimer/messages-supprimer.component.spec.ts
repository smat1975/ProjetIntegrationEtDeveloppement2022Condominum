﻿/// <reference path="../../../../node_modules/@types/jasmine/index.d.ts" />
import { TestBed, async, ComponentFixture, ComponentFixtureAutoDetect } from '@angular/core/testing';
import { BrowserModule, By } from "@angular/platform-browser";
import { MessagesSupprimerComponent } from './messages-supprimer.component';

let component: MessagesSupprimerComponent;
let fixture: ComponentFixture<MessagesSupprimerComponent>;

describe('MessagesSupprimer component', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ MessagesSupprimerComponent ],
            imports: [ BrowserModule ],
            providers: [
                { provide: ComponentFixtureAutoDetect, useValue: true }
            ]
        });
        fixture = TestBed.createComponent(MessagesSupprimerComponent);
        component = fixture.componentInstance;
    }));

    it('should do something', async(() => {
        expect(true).toEqual(true);
    }));
});