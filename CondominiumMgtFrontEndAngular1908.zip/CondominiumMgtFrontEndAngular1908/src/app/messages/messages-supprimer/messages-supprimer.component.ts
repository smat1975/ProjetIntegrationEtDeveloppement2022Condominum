import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/services/shared.service';
import { Messages } from 'src/app/shared/messages';
import { MessagesComplexe } from 'src/app/shared/messagescomplexe';
import { TypesMessage } from 'src/app/shared/types-message';

@Component({
    selector: 'app-messages-supprimer',
    templateUrl: './messages-supprimer.component.html',
    styleUrls: ['./messages-supprimer.component.css']
})

export class MessagesSupprimerComponent {

  private _id!: number;
  message!: MessagesComplexe;

  listTypesMessage: TypesMessage[] = [];

  constructor(
    public service: SharedService,
    public router: Router,
    private actRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.actRoute.paramMap.subscribe(params => {
      this._id = this.actRoute.snapshot.params['id'];
      //this._id = +params.get('id');
      this.service.getDetailsMessage(this._id).subscribe(
        (message) => /*this.message = message,*/
          console.log(this.message = message)
        //(err: any) => console.log(err)
      );
    });
    this.listTypesMessage = this.service.listTypesMessage;
  }
/*Ancienne version supprimée*/
  onSupprimerMessage() {
    this.service.supprimerMessage(this._id).subscribe(
      (message) => { }
    );
  };

  onSupprimerMessageBIS() {
    this.service.supprimerMessageBIS(this._id).subscribe(
      (message) => { }
    );
  };

  
  onSupprimerMessageById() {
    this.service.supprimerMessageById(this._id).subscribe(
      (message) => { }
    );
  };

  onSupprimerMessageDirecte() {
    this.service.supprimerMessageDirecte(this._id).subscribe(
      (message) => { }
    );
  };
}
