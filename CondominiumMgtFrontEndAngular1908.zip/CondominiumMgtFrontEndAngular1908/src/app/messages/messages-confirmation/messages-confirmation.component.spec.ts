﻿/// <reference path="../../../../node_modules/@types/jasmine/index.d.ts" />
import { TestBed, async, ComponentFixture, ComponentFixtureAutoDetect } from '@angular/core/testing';
import { BrowserModule, By } from "@angular/platform-browser";
import { MessagesConfirmationComponent } from './messages-confirmation.component';

let component: MessagesConfirmationComponent;
let fixture: ComponentFixture<MessagesConfirmationComponent>;

describe('MessagesConfirmation component', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ MessagesConfirmationComponent ],
            imports: [ BrowserModule ],
            providers: [
                { provide: ComponentFixtureAutoDetect, useValue: true }
            ]
        });
        fixture = TestBed.createComponent(MessagesConfirmationComponent);
        component = fixture.componentInstance;
    }));

    it('should do something', async(() => {
        expect(true).toEqual(true);
    }));
});