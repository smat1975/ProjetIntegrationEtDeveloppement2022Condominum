import { Component, Directive, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages';
import { TypesMessage } from 'src/app/shared/types-message';
import { SharedService } from 'src/app/services/shared.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-ajouter-messages',
  templateUrl: './ajouter-messages.component.html',
  styleUrls: ['./ajouter-messages.component.css']
})


export class AjouterMessagesComponent implements OnInit {
  // private _id!: number;
  message!: Messages;

  messageForm = this.fb.group({
    idExpediteur: [null, Validators.required],
    dateExpedition: [Date.now()],
    titreMessage: [null, Validators.required],
    contenuMessage: [null, Validators.required],
    idTypeMessage: [null, Validators.required],
    valididation: true
  });

  listTypesMessage: TypesMessage[] = [];


  constructor(
    private fb: FormBuilder,
    private service: SharedService,
    private actRoute: ActivatedRoute, 
  ) { }

  ngOnInit() {
    // this.actRoute.paramMap.subscribe(params => {
    //   this._id = this.actRoute.snapshot.params['id'];
    //   this._id = +params.get('id');
    // });

    this.listTypesMessage = this.service.listTypesMessage;
  }

  submitted = false;

  onSubmit(): void { 
    this.message = <Messages>this.messageForm.value;
    this.service.creerMessageRetry(this.message);
    this.submitted = true; 
  }

  //onCreerMessage() {
  //  this.service.creerMessage(this.message).subscribe(
  //    (message) => { }
  //  );
  //};

  //showSuccess() {
  //  this.toastr.success('Ajouter message', 'Message ajouté!');
  //}

}
 
  