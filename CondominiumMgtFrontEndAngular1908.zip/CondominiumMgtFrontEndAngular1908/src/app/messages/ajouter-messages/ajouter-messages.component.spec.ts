import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjouterMessagesComponent } from './ajouter-messages.component';

describe('AjouterMessagesComponent', () => {
  let component: AjouterMessagesComponent;
  let fixture: ComponentFixture<AjouterMessagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjouterMessagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AjouterMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
