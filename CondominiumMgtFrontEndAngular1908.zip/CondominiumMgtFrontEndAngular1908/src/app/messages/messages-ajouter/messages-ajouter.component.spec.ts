import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagesAjouterComponent } from './messages-ajouter.component';

describe('MessagesAjouterComponent', () => {
  let component: MessagesAjouterComponent;
  let fixture: ComponentFixture<MessagesAjouterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MessagesAjouterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagesAjouterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
