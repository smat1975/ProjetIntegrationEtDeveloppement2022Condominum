import { Component, Directive, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages';
import { MessagesToCreate } from 'src/app/shared/messagestocreate';
import { TypesMessage } from 'src/app/shared/types-message';
import { SharedService } from 'src/app/services/shared.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
//import { TypesMessageSelect } from 'src/app/shared/types-message';


@Component({
  selector: 'app-messages-ajouter',
  templateUrl: './messages-ajouter.component.html',
  styleUrls: ['./messages-ajouter.component.css']
})

export class MessagesAjouterComponent implements OnInit {
  private _id!: number;
  message!: MessagesToCreate;

messageForm =  new FormGroup(
  {
    idExpediteur: new FormControl(),
    dateExpedition:  new FormControl(Date.now()),
    titreMessage:  new FormControl(),
    contenuMessage: new FormControl(),
    idTypeMessage:  new FormControl(),
    annexes: new FormControl(),
    destinations:  new FormControl(),
    validation:  new FormControl(),
  });


  // messageForm = this.fb.group({
  //   idExpediteur: "st",
  //   dateExpedition: [Date.now()],
  //   titreMessage: ["Entrez un titre"],
  //   contenuMessage: ["Ajoutez un contenu"],
  //   idTypeMessage: 5,
  //   annexes: 1,
  //   destinations: "steph",
  //   validation: true
  // });

  typesMessage: TypesMessage[] = [
    { idTypeMessage: -1, denomination: 'Type du message', description: 'Choix du type de message' },
    { idTypeMessage: 1, denomination: 'Avertissement', description: 'Avertissement' },
    { idTypeMessage: 2, denomination: 'Information', description: 'Information' },
    { idTypeMessage: 3, denomination: 'Appel', description: 'Appel' },
    { idTypeMessage: 4, denomination: 'Rappel', description: 'Rappel' },
    { idTypeMessage: 5, denomination: 'Message publique', description: 'Message publique' },
  ];


  constructor(
    private fb: FormBuilder,
    private service: SharedService,
    private actRoute: ActivatedRoute, 
  ) { }

  ngOnInit() {
    this.actRoute.paramMap.subscribe(params => {
      this._id = this.actRoute.snapshot.params['id'];
      //this._id = +params.get('id');
    });
  }

  onSubmit(): void {
   this.message = <MessagesToCreate>this.messageForm.value;
   this.service.creerMessageRetry(this.message);
  }

  //onCreerMessage() {
  //  this.service.creerMessage(this.message).subscribe(
  //    (message) => { }
  //  );
  //};

  //showSuccess() {
  //  this.toastr.success('Ajouter message', 'Message ajouté!');
  //}

}
 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
//   private _id!: number;
//   message!: Messages;

//   messageForm = this.fb.group({
//     idExpediteur: [null, Validators.required],
//     dateExpedition: [Date.now()],
//     titreMessage: [null, Validators.required],
//     contenuMessage: [null, Validators.required],
//     idTypeMessage: [null, Validators.required],
//     validation: null
//   });
 
 
//  // typesMessage = ["1", "2", "3", "4", "5"];
//  typesMessage: number[] = [1, 2, 3, 4, 5]

//   constructor(
//     private fb: FormBuilder,
//     private service: SharedService,
//     private actRoute: ActivatedRoute, 
//     private router: Router,
    
//   ) { }

//   ngOnInit() {
//     this.actRoute.paramMap.subscribe(params => {
//       this._id = this.actRoute.snapshot.params['id'];
//       //this._id = +params.get('id');
//     });
//   }

//   onSubmit(): void {
//   //  this.message = <Messages>this.messageForm.value;
//    this.service.creerMessage(this.message);
//   }

//   //onCreerMessage() {
//   //  this.service.creerMessage(this.message).subscribe(
//   //    (message) => { }
//   //  );
//   //};

//   //showSuccess() {
//   //  this.toastr.success('Ajouter message', 'Message ajouté!');
//   //}

// goToMessagesListe(){
// this.router.navigate(['/messages-liste/']);  
// }

// }
