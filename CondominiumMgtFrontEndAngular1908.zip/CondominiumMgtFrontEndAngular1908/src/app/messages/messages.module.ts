import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, FormGroup, ReactiveFormsModule } from '@angular/forms';
//import { DetailsMessagesComponent } from 'src/app/messages/details-messages/details-messages.component';
//import { ListMessagesComponent } from 'src/app/messages/list-messages/list-messages.component';
import { MessagesListeComponent } from 'src/app/messages/messages-liste/messages-liste.component';
import { MessagesDetailsComponent } from 'src/app/messages/messages-details/messages-details.component';
import { MessagesComponent } from 'src/app/messages/messages.component';
import { MessagesFormComponent } from 'src/app/messages/messages-form/messages-form.component';
import { Component, OnInit } from '@angular/core'
import { AppRoutingModule } from 'src/app/app-routing.module';
import { SharedService } from 'src/app/services/shared.service';
import { Messages } from 'src/app/shared/messages';
import { MessagesToShow } from 'src/app/shared/messagestoshow';
import { MessagesFormToShow } from 'src/app/shared/messagesformtoshow';
import { RouterModule, Routes } from '@angular/router';
import { MessagesAjouterComponent } from './messages-ajouter/messages-ajouter.component';
import { MessagesModifierComponent } from './messages-modifier/messages-modifier.component';
import { MessagesSupprimerComponent } from './messages-supprimer/messages-supprimer.component';
import { AjouterMessagesComponent } from './ajouter-messages/ajouter-messages.component';

const messagesRoutes: Routes = [
  { path: 'messages-liste', component: MessagesListeComponent },
  { path: 'messages-details/:id', component: MessagesDetailsComponent },
  { path: 'ajouter-messages', component: AjouterMessagesComponent },
  { path: 'messages-ajouter', component: MessagesAjouterComponent },
  { path: 'messages-modifier/:id', component: MessagesModifierComponent },
  { path: 'messages-supprimer/:id', component: MessagesSupprimerComponent },
  { path: 'messages', component: MessagesComponent },
  // { path: 'messages-form/:id', component: MessagesFormComponent }
]

@NgModule({
  declarations: [
    MessagesListeComponent,
    MessagesDetailsComponent,
    MessagesAjouterComponent,
    MessagesModifierComponent,
    MessagesSupprimerComponent,
    MessagesComponent,
    // MessagesFormComponent,
    
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(messagesRoutes)
  ]
})
export class MessagesModule /*implements OnInit*/{ 


}
