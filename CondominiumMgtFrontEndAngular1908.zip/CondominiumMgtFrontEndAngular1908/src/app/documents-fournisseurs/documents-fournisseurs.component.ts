import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documents-fournisseurs',
  templateUrl: './documents-fournisseurs.component.html',
  styleUrls: ['./documents-fournisseurs.component.css']
})
export class DocumentsFournisseursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
