import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fournisseurs',
  templateUrl: './fournisseurs.component.html',
  styleUrls: ['./fournisseurs.component.css']
})
export class FournisseursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
