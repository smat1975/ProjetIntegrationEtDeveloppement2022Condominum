import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lignes-documents-fournisseurs',
  templateUrl: './lignes-documents-fournisseurs.component.html',
  styleUrls: ['./lignes-documents-fournisseurs.component.css']
})
export class LignesDocumentsFournisseursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
