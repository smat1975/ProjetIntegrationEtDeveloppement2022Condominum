import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LignesDocumentsFournisseursComponent } from './lignes-documents-fournisseurs.component';

describe('LignesDocumentsFournisseursComponent', () => {
  let component: LignesDocumentsFournisseursComponent;
  let fixture: ComponentFixture<LignesDocumentsFournisseursComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LignesDocumentsFournisseursComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LignesDocumentsFournisseursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
