import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoproprietairesComponent } from './coproprietaires.component';

describe('CoproprietairesComponent', () => {
  let component: CoproprietairesComponent;
  let fixture: ComponentFixture<CoproprietairesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoproprietairesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoproprietairesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
