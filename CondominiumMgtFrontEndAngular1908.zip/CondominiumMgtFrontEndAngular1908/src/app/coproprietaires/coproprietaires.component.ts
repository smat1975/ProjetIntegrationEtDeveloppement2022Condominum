import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coproprietaires',
  templateUrl: './coproprietaires.component.html',
  styleUrls: ['./coproprietaires.component.css']
})
export class CoproprietairesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
