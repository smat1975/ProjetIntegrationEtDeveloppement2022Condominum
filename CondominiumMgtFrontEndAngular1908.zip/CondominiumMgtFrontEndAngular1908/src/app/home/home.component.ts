import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { Messages } from 'src/app/shared/messages';
import { MessagesToShow } from 'src/app/shared/messagestoshow';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit{

 constructor(private service: SharedService) { }

  /* Ancienne version supprimée //ListeMessagesPublics: any = [];*/
 ListeAllMessagesPublicsToShow: any = [];

  ngOnInit(): void {
   this.refreshListeAllMessagesPublicsToShow();
  }

 refreshListeAllMessagesPublicsToShow() {
    this.service.getListeAllMessagesPublicsToShow().subscribe(data => {
      this.ListeAllMessagesPublicsToShow = data;
    });
  }

}
