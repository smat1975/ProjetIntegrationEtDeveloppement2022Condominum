﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CondominiumManagement.Models
{
    public class Sexes
    {
        public int IdSexe { get; set; }
        public string Denomination { get; set; }
        public string Remarque { get; set; }
    }
}
