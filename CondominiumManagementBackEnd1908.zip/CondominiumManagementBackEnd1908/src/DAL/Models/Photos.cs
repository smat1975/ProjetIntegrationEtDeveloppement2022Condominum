﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DAL.Models
{
    public class Photos
    {
        public int IdPhoto { get; set; }
        public int IdAnnexe { get; set; }
        public string Ressource { get; set; }

        public Annexes Annexe { get; set; }
    }
}
